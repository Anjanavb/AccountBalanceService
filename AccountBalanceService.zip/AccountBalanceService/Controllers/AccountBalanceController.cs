﻿using AccountBalanceService.Model;
using BalanceService.Data.Repository;
using BalanceService.Model;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BalanceService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountBalanceController : ControllerBase
    {
        private readonly IAccountBalanceRepository _balanceRepository;
        public AccountBalanceController(IAccountBalanceRepository balanceRepository)
        {
            _balanceRepository = balanceRepository;
        }

        [HttpGet("GetBalance")]
        public async Task<IActionResult> GetBalance([FromQuery] int accountId)
        {
            try
            {
                var balance = await _balanceRepository.GetCurrentBalanceAsync(accountId);
                var AccountBalanceResponds = new AccountBalanceResponds
                {
                    AccountBalance = balance
                };
                return Ok(AccountBalanceResponds);
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { Error = ex.Message });
            }
        }
        [HttpPost("debit")]
        public async Task<IActionResult> DebitAmount([FromBody] DebitRequest debitRequest)
        {
            try
            {
                bool isDebitSuccess = await _balanceRepository.DebitAmountAsync(debitRequest);
                if (isDebitSuccess)
                {
                    return Ok("Debit successful");
                }
                return StatusCode(StatusCodes.Status500InternalServerError, "Debit failed due to unknown error.");
            }
            catch (ArgumentException ex)
            {
                return NotFound(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                // Handle unexpected exceptions
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
    }
}
