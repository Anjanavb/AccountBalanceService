﻿namespace BalanceService.Enum
{
    public enum TransactionType
    {
        Debit,
        Credit
    }
}
