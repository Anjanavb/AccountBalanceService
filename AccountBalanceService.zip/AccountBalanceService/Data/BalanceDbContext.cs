﻿using System;
using Microsoft.EntityFrameworkCore;
using BalanceService.Enum;
using BalanceService.Model;

namespace BalanceService.Data
{
    public class BalanceDbContext : DbContext
    {
        public BalanceDbContext(DbContextOptions<BalanceDbContext> options) : base(options)
        {
            
        }
        public DbSet<AccountBalance> Accounts { get; set; }
        public DbSet<Transaction> Transactions { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AccountBalance>().HasData(new List<AccountBalance>
           {
               new AccountBalance {AccountID=1,Balance=5000},
               new AccountBalance {AccountID=2,Balance=5000},
               new AccountBalance {AccountID=3,Balance=5},
               new AccountBalance {AccountID=4,Balance=500},
               new AccountBalance {AccountID=5,Balance=1000},
               new AccountBalance {AccountID=6,Balance=1000},
           });
            modelBuilder.Entity<Transaction>().HasData(new List<Transaction>
           {
               new Transaction {TransactionID=1,AccountID=4,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=2,AccountID=4,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=3,AccountID=4,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=4,AccountID=4,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},

               new Transaction {TransactionID=5,AccountID=5,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=6,AccountID=5,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=7,AccountID=5,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=8,AccountID=5,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=9,AccountID=5,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=10,AccountID=5,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=11,AccountID=5,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=12,AccountID=5,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=13,AccountID=5,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=14,AccountID=5,Amount=51,Type=TransactionType.Debit,Date=DateTime.UtcNow},

               new Transaction {TransactionID=15,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=16,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=17,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=18,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=19,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=20,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=21,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=22,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=23,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=24,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=25,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=26,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=27,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=28,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=29,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=30,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=31,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=32,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=33,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=34,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=35,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=36,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=37,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=38,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=39,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=40,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=41,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=42,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=43,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow},
               new Transaction {TransactionID=44,AccountID=6,Amount=101,Type=TransactionType.Debit,Date=DateTime.UtcNow}

            });
       
            modelBuilder.Entity<AccountBalance>()
                .Property(t => t.Balance)
                .HasColumnType("decimal(18, 2)");

            modelBuilder.Entity<Transaction>()
             .HasOne(n => n.Account)
             .WithMany(n => n.Transactions)
             .HasForeignKey(n => n.AccountID)
             .HasConstraintName("FK_Transaction_Account");

            modelBuilder.Entity<Transaction>()
                .Property(t => t.Type)
                .HasConversion(
                v => v.ToString(),
                 v => (TransactionType)System.Enum.Parse(typeof(TransactionType), v));
            modelBuilder.Entity<Transaction>()
                .Property(t => t.Amount)
                .HasColumnType("decimal(18, 2)");
        }
    }
}
