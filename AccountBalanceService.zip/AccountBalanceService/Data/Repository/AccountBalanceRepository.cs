﻿using AccountBalanceService.Model;
using BalanceService.Enum;
using BalanceService.Model;
using Microsoft.EntityFrameworkCore;
using System.Runtime.CompilerServices;

namespace BalanceService.Data.Repository
{
    public class AccountBalanceRepository : IAccountBalanceRepository
    {
        private readonly BalanceDbContext _balanceDbContext;
        public AccountBalanceRepository(BalanceDbContext balanceDbContext)
        {
            _balanceDbContext = balanceDbContext;
        }
        public async Task<decimal> GetCurrentBalanceAsync(int accountID)
        {
            try
            {
                var account = await _balanceDbContext.Accounts.AsNoTracking()
                    .SingleOrDefaultAsync(a => a.AccountID == accountID);

                if (account == null)
                {
                    throw new ArgumentException("Account not found");
                }
                return account.Balance;
            }
            catch (ArgumentException ex)
            {
                throw; 
            }
            catch (Exception ex)
            {
                throw new ApplicationException("An unexpected error occurred while retrieving the balance.", ex);
            }
        }
        public async Task<bool> DebitAmountAsync(DebitRequest  debitRequest)
        {
            try
            {
                // Retrieve the account
                var account = await _balanceDbContext.Accounts.FindAsync(debitRequest.AccountId);
                if (account == null)
                {
                    throw new ArgumentException("Account not found");
                }

                if (account.Balance < debitRequest.Amount)
                {
                    throw new InvalidOperationException("Insufficient funds");
                }

                // Deduct the amount from the account balance
                account.Balance -= debitRequest.Amount;

                // Create a new transaction record
                var transaction = new Transaction
                {
                    AccountID = debitRequest.AccountId,
                    Amount = -debitRequest.Amount,
                    Date = DateTime.UtcNow,
                    Type = TransactionType.Debit
                };

                _balanceDbContext.Transactions.Add(transaction);
                await _balanceDbContext.SaveChangesAsync();

                _balanceDbContext.Accounts.Update(account);
                await _balanceDbContext.SaveChangesAsync();

                return true;
            }
            catch (ArgumentException ex)
            {
                throw;
            }
            catch (InvalidOperationException ex)
            {
                throw;
            }
            catch (DbUpdateException ex)
            {
                throw new ApplicationException("An error occurred while updating the database.", ex);
            }
            catch (Exception ex)
            {
                throw new ApplicationException("An unexpected error occurred during the debit operation.", ex);
            }
        }
    }
}
