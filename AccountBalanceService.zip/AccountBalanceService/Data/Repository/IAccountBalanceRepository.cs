﻿using AccountBalanceService.Model;
using BalanceService.Model;
using AccountBalanceService.Model;

namespace BalanceService.Data.Repository
{
    public interface IAccountBalanceRepository
    {
        Task<decimal> GetCurrentBalanceAsync(int accountID);
        Task<bool> DebitAmountAsync(DebitRequest debitRequest);
    }
}
