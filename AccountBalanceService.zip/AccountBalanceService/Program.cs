using Microsoft.EntityFrameworkCore;
using BalanceService.Data;
using BalanceService.Data.Repository;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddTransient<IAccountBalanceRepository, AccountBalanceRepository>();
builder.Services.AddDbContext<BalanceDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("BalanceServiceDbContext") ?? throw new InvalidOperationException("Connection string 'RechargeSystemDbContext' not found.")));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
