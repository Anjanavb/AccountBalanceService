﻿using System.ComponentModel.DataAnnotations;

namespace BalanceService.Model
{
    public class AccountBalance
    {
        [Key]
        public int AccountID { get; set; }
        [Required]
        public decimal Balance { get; set; }
        public ICollection<Transaction> Transactions { get; set; }
    }
}
