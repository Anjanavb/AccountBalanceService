﻿namespace AccountBalanceService.Model
{
    public class AccountBalanceResponds
    {
        public decimal AccountBalance { get; set; }
    }
}
