﻿namespace AccountBalanceService.Model
{
    public class DebitRequest
    {
        public int AccountId { get; set; }
        public decimal Amount { get; set; }
    }
}
