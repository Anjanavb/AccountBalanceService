﻿using BalanceService.Enum;
using System.ComponentModel.DataAnnotations;

namespace BalanceService.Model
{
    public class Transaction
    {
        [Key]
        public int TransactionID { get; set; }
        public int AccountID { get; set; }
        [Required]
        public decimal Amount { get; set; }
        [Required]
        public DateTime Date { get; set; }
        [Required]
        public TransactionType Type { get; set; } 

        public AccountBalance Account { get; set; }
    }
}
