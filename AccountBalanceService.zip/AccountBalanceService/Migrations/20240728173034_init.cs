﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace AccountBalanceService.Migrations
{
    /// <inheritdoc />
    public partial class init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Accounts",
                columns: table => new
                {
                    AccountID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Balance = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Accounts", x => x.AccountID);
                });

            migrationBuilder.CreateTable(
                name: "Transactions",
                columns: table => new
                {
                    TransactionID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AccountID = table.Column<int>(type: "int", nullable: false),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Type = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Transactions", x => x.TransactionID);
                    table.ForeignKey(
                        name: "FK_Transaction_Account",
                        column: x => x.AccountID,
                        principalTable: "Accounts",
                        principalColumn: "AccountID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Accounts",
                columns: new[] { "AccountID", "Balance" },
                values: new object[,]
                {
                    { 1, 5000m },
                    { 2, 5000m },
                    { 3, 5m },
                    { 4, 500m },
                    { 5, 1000m },
                    { 6, 1000m }
                });

            migrationBuilder.InsertData(
                table: "Transactions",
                columns: new[] { "TransactionID", "AccountID", "Amount", "Date", "Type" },
                values: new object[,]
                {
                    { 1, 4, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2647), "Debit" },
                    { 2, 4, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2650), "Debit" },
                    { 3, 4, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2651), "Debit" },
                    { 4, 4, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2652), "Debit" },
                    { 5, 5, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2654), "Debit" },
                    { 6, 5, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2655), "Debit" },
                    { 7, 5, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2657), "Debit" },
                    { 8, 5, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2658), "Debit" },
                    { 9, 5, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2659), "Debit" },
                    { 10, 5, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2661), "Debit" },
                    { 11, 5, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2662), "Debit" },
                    { 12, 5, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2663), "Debit" },
                    { 13, 5, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2664), "Debit" },
                    { 14, 5, 51m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2665), "Debit" },
                    { 15, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2666), "Debit" },
                    { 16, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2667), "Debit" },
                    { 17, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2668), "Debit" },
                    { 18, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2669), "Debit" },
                    { 19, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2670), "Debit" },
                    { 20, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2671), "Debit" },
                    { 21, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2672), "Debit" },
                    { 22, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2674), "Debit" },
                    { 23, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2675), "Debit" },
                    { 24, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2676), "Debit" },
                    { 25, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2677), "Debit" },
                    { 26, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2695), "Debit" },
                    { 27, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2697), "Debit" },
                    { 28, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2698), "Debit" },
                    { 29, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2699), "Debit" },
                    { 30, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2700), "Debit" },
                    { 31, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2701), "Debit" },
                    { 32, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2702), "Debit" },
                    { 33, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2703), "Debit" },
                    { 34, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2705), "Debit" },
                    { 35, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2706), "Debit" },
                    { 36, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2707), "Debit" },
                    { 37, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2708), "Debit" },
                    { 38, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2709), "Debit" },
                    { 39, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2710), "Debit" },
                    { 40, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2711), "Debit" },
                    { 41, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2712), "Debit" },
                    { 42, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2713), "Debit" },
                    { 43, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2714), "Debit" },
                    { 44, 6, 101m, new DateTime(2024, 7, 28, 17, 30, 34, 296, DateTimeKind.Utc).AddTicks(2715), "Debit" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Transactions_AccountID",
                table: "Transactions",
                column: "AccountID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Transactions");

            migrationBuilder.DropTable(
                name: "Accounts");
        }
    }
}
